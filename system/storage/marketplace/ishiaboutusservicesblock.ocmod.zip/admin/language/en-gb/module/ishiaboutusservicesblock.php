<?php
// Heading
$_['heading_title']	       = '<img src="view/image/ishi-icon.png"> <b>Ishi About Us Services Block</b>';

$_['heading_title1']     = 'Ishi About Us Services Block';

// Text
$_['text_extension']    = 'Extensions';
$_['text_success']      = 'Success: You have modified Ishi About Us Services Block module!';
$_['text_edit']         = 'Edit Ishi About Us Services Block Module';

// Entry
$_['entry_name']        = 'Module Name';
$_['entry_title']       = 'Heading Title';
$_['entry_description'] = 'Description';
$_['entry_status']      = 'Status';
$_['entry_service_title']= 'Title';
$_['entry_image']      = 'icon/image Upload';
$_['entry_column']      = 'column';
$_['entry_height']      = 'Height';
$_['entry_width']      = 'Width';
$_['entry_title']      = 'Title';
$_['entry_showtitle']  = 'Show Title';



// Error
$_['error_permission']  = 'Warning: You do not have permission to modify Ishi About Us Services Block module!';
$_['error_name']        = 'Module Name must be between 3 and 64 characters!';