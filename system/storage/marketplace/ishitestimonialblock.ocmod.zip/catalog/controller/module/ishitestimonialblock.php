<?php
namespace Opencart\Catalog\Controller\Extension\ishitestimonialblock\Module;
class IshiTestimonialBlock extends \Opencart\System\Engine\Controller {

	public function index(array $setting): string {
		static $module = 0;		

		$this->load->language('extension/ishitestimonialblock/module/ishitestimonialblock');
		
		$this->load->model('tool/image');
		
		//$this->load->model('extension/ishitestimonialblock/module/ishitestimonialblock');
		

		$language_id = $this->config->get('config_language_id');
		$data['testimonials'] = array();
		$testimonials = $setting['ishitestimonial'];
		
		$data['ishi_randomnumer'] = "ishitestimonialblock-" . rand();
		$data['autoplay'] = (isset($setting['autoplay']) && $setting['autoplay'] == '1') ? 1 : 0;
		
		$lang = $this->config->get('config_language_id');

		if(!empty($setting['image'])) {
			if ($this->request->server['HTTPS']) {
				$data['image'] = $this->config->get('config_ssl') . 'image/' . $setting['image'];
			} else {
				$data['image'] = $this->config->get('config_url') . 'image/' . $setting['image'];
			}
 		}	

 		if(isset($setting['title'][$language_id])){
			$data['heading'] = $setting['title'][$language_id];
		}

		if(isset($setting['subtitle'][$language_id])){
			$data['subtitle'] = $setting['subtitle'][$language_id];
		}

		$data['bg_color'] = $setting['bg_color'];
		
		if(!empty($testimonials)){

			foreach ($testimonials as $testimonial) {
				
					$data['testimonials'][] = array(
						'description' => html_entity_decode($testimonial['description'], ENT_QUOTES, 'UTF-8'),
						'username'  => $testimonial['username'],
						'designation'  => $testimonial['designation']
					);
			}
		}
		
		$data['module'] = $module++;
	
		return $this->load->view('extension/ishitestimonialblock/module/ishitestimonialblock', $data);
	}
	
}
 