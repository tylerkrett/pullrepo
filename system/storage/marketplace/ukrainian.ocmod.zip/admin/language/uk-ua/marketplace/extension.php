<?php
// Heading
$_['heading_title'] = 'Розширення';

// Text
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_list'] = 'Список розширень';
$_['text_type'] = 'Виберіть тип розширення';
$_['text_filter'] = 'Фільтр';