<?php
// Heading
$_['heading_title'] = 'Авторизація';

// Text
$_['text_heading'] = 'Авторизація';
$_['text_login'] = 'Введіть логін та пароль';
$_['text_forgotten'] = 'Забули пароль?';

// Entry
$_['entry_username'] = 'Логін';
$_['entry_password'] = 'Пароль';

// Button
$_['button_login'] = 'Увійти';

// Error
$_['error_login'] = 'Такий логін та/або пароль не існує!';
$_['error_token'] = 'Неправильна токен-сесія. Авторизуйтесь знову.';