<?php
// Heading Title
$_['heading_title'] = 'Просування';