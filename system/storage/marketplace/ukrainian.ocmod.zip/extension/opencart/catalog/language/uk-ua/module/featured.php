<?php
// Heading
$_['heading_title'] = 'Рекомендовані товари';