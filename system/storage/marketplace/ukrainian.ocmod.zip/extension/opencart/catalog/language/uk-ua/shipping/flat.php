<?php
// Heading
$_['heading_title'] = 'Доставка';

// Text
$_['text_description'] = 'Доставка з фіксованою вартістю';