<?php
// Heading
$_['heading_title'] = 'Хіти продажів';