<?php
// Heading
$_['heading_title'] = 'Історія транзакцій';

// Column
$_['column_date_added'] = 'Додано';
$_['column_description'] = 'Опис';
$_['column_amount'] = 'Сума (%s)';

// Text
$_['text_account'] = 'Особистий кабінет';
$_['text_transaction'] = 'Ваші транзакції';
$_['text_total'] = 'Ваш поточний баланс';
$_['text_no_results'] = 'У Вас не було транзакцій!';