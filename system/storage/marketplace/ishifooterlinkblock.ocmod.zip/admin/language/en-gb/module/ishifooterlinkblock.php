<?php
// Heading
$_['heading_title']	       = '<img src="view/image/ishi-icon.png"> <b>Ishi FooterLink Block</b>';

$_['heading_title1']    = 'Ishi FooterLink Block';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Ishi FooterLink Block!';
$_['text_edit']        = 'Edit Ishi FooterLink Block';


$_['entry_name']    = 'Module Name';
$_['entry_column']     = 'Column';
$_['entry_footerlinktitle']     = 'Footer Link Title';
$_['entry_showtitle']  = 'Show Footer Title';
$_['entry_width']      = 'Payment Width';
$_['entry_showaccount']    = 'Show Account Link';
$_['entry_showinformation']    = 'Show Information Link';
$_['entry_showextra']    = 'Show Extra Link';
$_['entry_linkname']    	= 'Link name';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Ishi FooterLink Block!';
$_['error_name']       = 'Module Name must be between 3 and 64 characters!';