<?php
// Text
$_['heading_featured']      = 'featured';
$_['heading_bestseller']      = 'best sellers';
$_['heading_new']      = 'new Arrivals';
$_['heading_special']      = 'special Products';
$_['heading_category']      = 'Category Products';
$_['sub-title']				='Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor 							  incididunt ut labore';
$_['days_name']             = 'Days';
$_['hours_name']            = 'Hours';
$_['min_name']              = 'Min';
$_['sec_name']              = 'Sec';


$_['heading_feature']      = 'Featured';
$_['heading_offer']      = 'Special offer';
$_['heading_sale']      = 'On sale';
$_['heading_seller']      = 'Best Seller';

// Text
$_['text_tax']      = 'Ex Tax:';