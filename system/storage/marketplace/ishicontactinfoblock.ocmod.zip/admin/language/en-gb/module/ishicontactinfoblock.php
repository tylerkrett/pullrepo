<?php
// Heading
$_['heading_title']	       = '<img src="view/image/ishi-icon.png"> <b>Ishi Contactinfo Block</b>';

$_['heading_title1']    = 'Ishi Contactinfo Block';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Ishi Contactinfo Block!';
$_['text_edit']        = 'Edit Ishi Contactinfo Block';


$_['entry_name']    = 'Module Name';
$_['entry_title']        	= 'Title';
$_['entry_column']     = 'Column';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Ishi Contactinfo Block!';
$_['error_name']       = 'Module Name must be between 3 and 64 characters!';