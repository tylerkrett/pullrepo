<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading Title
$_['heading_title']	= 'العروض الترويجية';
