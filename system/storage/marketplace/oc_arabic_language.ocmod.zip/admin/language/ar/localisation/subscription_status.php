<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']      = 'حالات الاشتراك';

// Text
$_['text_success']       = 'تم التعديل !';
$_['text_list']          = 'قائمة';
$_['text_add']           = 'ادراج';
$_['text_edit']          = 'تحرير';

// Column
$_['column_name']        = 'اسم حالات الاشتراك';
$_['column_action']      = 'تحرير';

// Entry
$_['entry_name']         = 'اسم حالات الاشتراك';

// Error
$_['error_permission']   = 'تحذير: انت لا تمتلك صلاحيات التعديل !';
$_['error_name']         = 'اسم حالات الاشتراك يجب ان يكون بين 3 و 32 حرف!';
$_['error_default']      = 'تحذير: لا يمكن حذف حالات الاشتراك الافتراضية !';
$_['error_subscription'] = 'تحذير: لا يمكن الحذف لأنه مرتبط بالاشتراك %s !';
