<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Error
$_['error_extension'] = 'تحذير: لم يتم العثور على موديول طريقة الدفع !';
$_['error_recurring'] = 'تحذير: طريقة الدفع لا يتوفر بها خاصية تجديد الاشتراك التلقائي !';
$_['error_payment']   = 'تحذير: طريقة الدفع %s لم يتم العثور عليها !';
