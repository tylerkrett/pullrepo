<?php
// Text
$_['text_subject']   = '%s - GDPR request has been processed!';
$_['text_request']   = 'Account Deletion Request';
$_['text_hello']     = 'Hello <strong>%s</strong>,';
$_['text_user']      = 'User';
$_['text_delete']    = 'Your GDPR data deletion request has now been completed.';
$_['text_contact']   = 'For more information you can contact the store owner here:';
$_['text_thanks']    = 'Thanks,';

// Button
$_['button_contact'] = 'Contact Us';