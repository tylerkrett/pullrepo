<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject'] = 'إعادة تعيين محاولات رمز الحماية';
$_['text_reset']   = 'شخص ما أدخل رمز الحماية بشكل خاطئ أكثر من 3 مرات.';
$_['text_link']    = 'انقر فوق الارتباط أدناه لإعادة تعيين أمان الحساب :';
$_['text_ip']      = 'رقم الآي بي :';
$_['text_regards'] = 'مع أطيب التحيات';
