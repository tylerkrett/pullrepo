<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']  = '%s - نقاط المكافآت';
$_['text_received'] = 'لقد استلمت %s نقاط مكافآت !';
$_['text_total']    = 'إجمالي نقاط المكافآت الخاصة حالياً هو %s.';
