<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'الصفحة غير موجودة!';

// Text
$_['text_not_found'] = 'الصفحة التي طلبتها غير موجودة ! الرجاء ابلاغ المدير اذا تكررت هذه المشكلة.';
