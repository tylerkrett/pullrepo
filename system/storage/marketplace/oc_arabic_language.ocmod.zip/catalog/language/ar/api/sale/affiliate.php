<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']    = 'سيتم تطبيق عمولة الإحالة على هذا الطلب !';
$_['text_remove']     = 'تمت إزالة خصم القسيمة الخاص بك !';

// Error
$_['error_affiliate'] = 'تحذير: تعذر العثور على العمولة !';
