<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success'] = 'نجاح: تم تطبيق خصم القسيمة الخاص بك !';
$_['text_remove']  = 'نجاح: تمت إزالة خصم القسيمة الخاص بك !';

// Error
$_['error_coupon'] = 'تحذير: القسيمة إما غير صالحة أو منتهية الصلاحية أو وصلت إلى حد استخدامها !';
