<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']  = 'تم تطبيق خصم نقاط المكافأة الخاص بك !';
$_['text_remove']   = 'تمت إزالة خصم نقاط المكافأة الخاص بك !';

// Error
$_['error_reward']  = 'تحذير: الرجاء إدخال مقدار نقاط المكافأة المراد استخدامها !';
$_['error_points']  = 'تحذير: ليس لديك %s نقاط مكافأة !';
$_['error_maximum'] = 'تحذير: الحد الأقصى لعدد النقاط التي يمكن استخدامها هو  %s !';
