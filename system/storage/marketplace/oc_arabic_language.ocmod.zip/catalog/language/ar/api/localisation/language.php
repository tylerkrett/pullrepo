<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']   = 'تم التعديل !';

// Error
$_['error_language'] = 'تحذير: تعذر العثور على اللغة !';
