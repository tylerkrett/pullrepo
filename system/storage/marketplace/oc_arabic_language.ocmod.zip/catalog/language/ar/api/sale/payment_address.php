<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']       = 'نجاح: تم تحديد عنوان الدفع !';

// Error
$_['error_firstname']    = 'يجب أن يكون الاسم الأول بين 1 و 32 حرفًا !';
$_['error_lastname']     = 'الاسم الاخير يجب أن يكون بين 1 و 32 حرفاً !';
$_['error_address_1']    = 'العنوان 1 يجب أن يكون بين 3 و 128 رمز !';
$_['error_city']         = 'المدينة يجب ان تكون بين 3 و 128 رمز !';
$_['error_postcode']     = 'الرمز البريدي يجب ان يكون بين 2 و 10 رمز لهذه الدولة !';
$_['error_country']      = 'الرجاء اختيار الدولة !';
$_['error_zone']         = 'الرجاء تحديد منطقة / ولاية !';
$_['error_custom_field'] = '%s مطلوب !';
$_['error_regex']        = '%s ليس إدخالاً صالحًا !';
