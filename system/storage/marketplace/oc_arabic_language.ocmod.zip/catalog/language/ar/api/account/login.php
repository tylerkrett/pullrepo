<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']     = 'بدأت جلسة API بنجاح !';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات التعديل !';
$_['error_key']        = 'تحذير: مفتاح API غير صحيح !';
$_['error_ip']         = 'تحذير: رقم الآي بي الخاص بك %s غير مسموح له بالوصول إلى واجهة برمجة التطبيقات هذه!';
