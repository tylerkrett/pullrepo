<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']          = 'نجاح: تم تحديد طريقة الدفع !';

// Error
$_['error_payment_address'] = 'تحذير: عنوان الدفع مطلوب !';
$_['error_payment_method']  = 'تحذير: طريقة الدفع مطلوبة !';
$_['error_no_payment']      = 'تحذير: لا توجد خيارات دفع متاحة !';
$_['error_product']         = 'تحذير: المنتجات المطلوبة !';
