<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success'] = 'تم التعديل !';

// Error
$_['error_store']  = 'تحذير: لا يمكن العثور على المتجر !';
