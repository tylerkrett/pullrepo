<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']                  = 'اتمام الطلب';

// Text
$_['text_cart']                      = 'عربة التسوق';
