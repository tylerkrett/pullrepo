<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']          = 'طريقة الشحن';

// Text
$_['text_success']           = 'لقد قمت بتغيير طريقة الشحن بنجاح !';

// Error
$_['error_shipping_address'] = 'مطلوب !';
$_['error_shipping_method']  = 'مطلوب !';
$_['error_no_shipping']      = 'تحذير : طريقة الشحن غير متوفرة حالياً. الرجاء <a href="%s">الاتصال بنا</a> لمساعدتك!';
