<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'خريطة الموقع';

// Text
$_['text_special']     = 'العروض المميزة';
$_['text_account']     = 'حسابي';
$_['text_edit']        = 'معلومات الحساب';
$_['text_password']    = 'كلمة المرور';
$_['text_address']     = 'دفتر العناوين';
$_['text_history']     = 'طلباتي';
$_['text_download']    = 'روابط التنزيل';
$_['text_cart']        = 'عربة التسوق';
$_['text_checkout']    = 'اتمام الطلب';
$_['text_search']      = 'بحث';
$_['text_information'] = 'معلومات';
$_['text_contact']     = 'اتصل بنا';
