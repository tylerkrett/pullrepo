<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_items']                 = '%s منتجات - %s';
$_['text_subscription']          = 'خطة الاشتراك';
$_['text_subscription_trial']    = '%s كل %d %s for %d دفعة ثم ';
$_['text_subscription_duration'] = '%s كل %d %s for %d دفعة';
$_['text_subscription_cancel']   = '%s كل %d %s حتى الالغاء';
$_['text_day']                   = 'يوم';
$_['text_week']                  = 'اسبوع';
$_['text_semi_month']            = 'نصف شهري';
$_['text_month']                 = 'شهر';
$_['text_year']                  = 'سنة';
$_['text_no_results']            = 'سلة الشراء فارغة !';
$_['text_cart']                  = 'معاينة السلة';
$_['text_checkout']              = 'اتمام الطلب';
