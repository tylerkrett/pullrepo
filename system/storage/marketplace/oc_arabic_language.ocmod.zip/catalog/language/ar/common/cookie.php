<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success'] = 'شكرا لإعلامنا باختيارك !';
$_['text_cookie']  = 'هذا الموقع يستخدم ملفات تعريف الارتباط. للمزيد من المعلومات <a href="%s" class="alert-link modal-link">الرجاء النقر هنا</a>.';

// Button
$_['button_agree']    = 'نعم، ذلك جيد !';
$_['button_disagree'] = 'لا، شكراً !';
