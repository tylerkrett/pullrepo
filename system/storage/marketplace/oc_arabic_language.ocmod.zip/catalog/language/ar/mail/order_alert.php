<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']      = '%s - الطلب %s';
$_['text_received']     = 'طلب جديد من المتجر.';
$_['text_order_id']     = 'رقم الطلب:';
$_['text_date_added']   = 'تاريخ الطلب:';
$_['text_order_status'] = 'حالة الطلب:';
$_['text_product']      = 'الطلبات';
$_['text_total']        = 'الاجمالي';
$_['text_comment']      = 'الملاحظات على طلبك هي :';
