<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']      = 'بطاقة الائتمان';

// Text
$_['text_description']   = 'طريقة الدفع هذه هي طريقة وهمية ولن تخزن معلومات بطاقة الائتمان ولا يجب استخدامها على موقع مباشر. هذا الموديول هنا للمطورين الذين يحتاجون إلى إنشاء تكامل بوابة دفع.';
$_['text_extension']     = 'الموديولات';
$_['text_success']       = 'تم التعديل!';
$_['text_edit']          = 'تحرير';
$_['text_approve']       = 'موافقة';
$_['text_deny']          = 'رفض';

// Entry
$_['entry_response']     = 'معالجة استجابة البطاقة';

$_['entry_response']     = 'معالجة استجابة البطاقة';
$_['entry_response']     = 'معالجة استجابة البطاقة';
$_['entry_response']     = 'معالجة استجابة البطاقة';


$_['entry_order_status'] = 'حالة الطلب';
$_['entry_fraud_status'] = 'حالة الطلب';
$_['entry_complete_status'] = 'حالة الطلب';

$_['entry_subscription_status'] = 'حالة الطلب';

$_['entry_geo_zone']     = 'المنطقة الجغرافية';
$_['entry_status']       = 'الحالة';
$_['entry_sort_order']   = 'ترتيب الفرز';

// Help
$_['help_response']      = 'اختر ما إذا كانت بطاقة الائتمان يجب أن تعيد الموافقة أو المرفوضة عند إجراء أوامر الاختبار';

// Error
$_['error_permission']   = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
