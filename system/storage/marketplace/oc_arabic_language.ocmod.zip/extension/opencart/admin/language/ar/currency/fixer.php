<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'Fixer';

// Text
$_['text_extension']   = 'الموديولات';
$_['text_success']	   = 'تم التعديل!';
$_['text_edit']        = 'تحرير';
$_['text_signup']      = 'Fixer.io is a currency conversion service <a href="https://fixer.io/" target="_blank" class="alert-link">signup here</a>.';
$_['text_support']     = 'يتطلب هذا الموديول أن يكون خيار العملة متاحًا بعملة اليورو.';

// Entry
$_['entry_api']        = 'API Access Key';
$_['entry_status']     = 'الحالة';

// Error
$_['error_permission'] = 'تحذير: أنت لا تمتلك صلاحيات التعديل!';
$_['error_api']        = 'مطلوب !';
