<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'طرق الشحن';

// Text
$_['text_weight']   = 'الوزن :';
