<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'تـحـويـل بـنـكـي';

// Text
$_['text_instruction'] = 'تعليمات التـحـويـل البـنـكـي';
$_['text_description'] = 'الرجاء تحويل المبلغ إلى أحد حساباتنا البنكية.';
$_['text_payment']     = 'سوف تكتمل عملية الطلب حال انهاء التحويل البنكي وافادتنا بمعلومات التحويل.';
