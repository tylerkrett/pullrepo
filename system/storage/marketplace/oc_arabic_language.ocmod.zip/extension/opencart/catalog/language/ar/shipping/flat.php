<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'تكلفة ثابتة';

// Text
$_['text_description'] = 'تكلفة ثابتة للشحن';
