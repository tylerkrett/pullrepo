<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'بالقطعة';

// Text
$_['text_description'] = 'قيمة الشحن للقطعة';
