<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']        = 'الدفع عند الاستلام';

// Error
$_['error_order_id']       = 'لا يوجد معرّف طلب في الجلسة !';
$_['error_payment_method'] = 'طريقة الدفع غير صحيحة !';
