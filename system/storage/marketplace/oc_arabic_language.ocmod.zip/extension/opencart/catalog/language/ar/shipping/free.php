<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'شحن مجاني';

// Text
$_['text_description'] = 'شحن مجاني';
