<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'استخدم نقاط المكافآت (%s)';

// Text
$_['text_reward']   = 'نقاط المكافآت (%s)';
$_['text_order_id'] = 'رقم الطلب: #%s';
$_['text_success']  = 'تم قبول خصم نقاط المكافآت !';
$_['text_remove']   = 'تمت إزالة خصم نقاط المكافأة الخاص بك !';

// Entry
$_['entry_reward']  = 'الرجاء ادخال نقاط المكافآت (المتاح %s)';

// Error
$_['error_reward']  = 'تحذير: الرجاء ادخال عدد نقاط المكافآت المطلوب استخدامها !';
$_['error_points']  = 'تحذير: لايوجد لديك %s نقاط !';
$_['error_maximum'] = 'تحذير: أقصى حد لاستخدام النقاط هو %s !';
$_['error_status']  = 'تحذير: لم يتم تمكين نقاط المكافآت في هذا المتجر !';
