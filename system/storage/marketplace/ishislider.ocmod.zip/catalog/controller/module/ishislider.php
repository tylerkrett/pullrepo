<?php
namespace Opencart\Catalog\Controller\Extension\ishislider\Module;
class IshiSlider extends \Opencart\System\Engine\Controller {
	public function index(array $setting): string {
		
		static $module = 0;
		$this->load->model('tool/image');

		$language_id = $this->config->get('config_language_id');
		$ishiservices = array();
		$data['ishi_randomnumer'] = "ishislider-" . rand();
		
		$data['autoplay'] = (isset($setting['autoplay']) && $setting['autoplay'] == '1') ? 'true' : 'false';
		
		$data['navigation'] = (isset($setting['navigation']) && $setting['navigation'] == '1') ? 'true' : 'false';
		$data['navigation_style'] = $setting['navigation_style'];
		$data['dot'] = (isset($setting['dot']) && $setting['dot'] == '1') ? 'true' : 'false';
		$data['dot_style'] = $setting['dot_style'];

		if(isset($setting['service'][$language_id])){
			$ishiservices = $setting['service'][$language_id];
		}
		
		foreach ($ishiservices as $ishiservice) {
			if(isset($ishiservice['image'])){
			$serviceiimage = $this->model_tool_image->resize($ishiservice['image'], $setting['width'], $setting['height']);
			}
			if(isset($ishiservice['imagehover'])){
			$serviceiimage = $this->model_tool_image->resize($ishiservice['imagehover'], $setting['mobilewidth'], $setting['mobileheight']);
			}
			$data['ishiservices'][] = array(
				'image' => $serviceiimage,
				'title' => $ishiservice['title'],
				'titlecolor' => $ishiservice['titlecolor'],
				'subtitle' => $ishiservice['subtitle'],
				'subtitlecolor' => $ishiservice['subtitlecolor'],
				'desc'  => $ishiservice['desc'],
				'desccolor'  => $ishiservice['desccolor'],
				'textalignment' => $ishiservice['textalignment'],
				'textposition' => $ishiservice['textposition'],
				'mobiletextalignment' => $ishiservice['mobiletextalignment'],
				'mobiletextposition' => $ishiservice['mobiletextposition'],
				'btntext'  => $ishiservice['btntext'],
				'link'  => $ishiservice['link'],
				'image' => $this->model_tool_image->resize($ishiservice['image'], $setting['width'], $setting['height']),
				'imagehover' => $this->model_tool_image->resize($ishiservice['imagehover'], $setting['mobilewidth'], $setting['mobileheight']),
			);
		}
		
		return $this->load->view('extension/ishislider/module/ishislider', $data);
	}
}