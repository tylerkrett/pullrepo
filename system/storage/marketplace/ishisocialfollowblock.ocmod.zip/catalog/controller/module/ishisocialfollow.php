<?php
namespace Opencart\Catalog\Controller\Extension\ishisocialfollowblock\Module;
class IshiSocialFollow extends \Opencart\System\Engine\Controller {
	public function index(array $setting): string {
		$this->load->language('extension/ishisocialfollowblock/module/ishisocialfollow');

		if ($setting['facebook']) {
			$data['facebook'] = $setting['facebook'];
		}
		if ($setting['twitter']) {
			$data['twitter'] = $setting['twitter'];
		}
		if ($setting['youtube']) {
			$data['youtube'] = $setting['youtube'];
		}
		if ($setting['gplus']) {
			$data['gplus'] = $setting['gplus'];
		}
		if ($setting['rss']) {
			$data['rss'] = $setting['rss'];
		}
		if ($setting['pinterest']) {
			$data['pinterest'] = $setting['pinterest'];
		}
		if ($setting['vimeo']) {
			$data['vimeo'] = $setting['vimeo'];
		}
		if ($setting['instagram']) {
			$data['instagram'] = $setting['instagram'];
		}

		return $this->load->view('extension/ishisocialfollowblock/module/ishisocialfollow', $data);
	}
}