<?php
// Heading
$_['heading_title']    = 'Русский язык';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили русский язык!';
$_['text_edit']        = 'Редактировать русский язык';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Предупреждение: У вас нет прав на изменение русского языка!';
