<?php
// Heading
$_['heading_title']    = 'Темы';

// Text
$_['text_success']     = 'Успех: Вы изменили темы!';

// Column
$_['column_name']      = 'Название темы';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение тем!';
$_['error_directory']  = 'Внимание: Каталог расширения не существует!';
