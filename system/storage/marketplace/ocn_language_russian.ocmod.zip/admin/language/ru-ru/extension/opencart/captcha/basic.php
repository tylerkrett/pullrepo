<?php
// Heading
$_['heading_title']    = 'Базовая капча';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили базовую капчу!';
$_['text_edit']        = 'Редактирование базовой капчи';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение базовой капчи!';