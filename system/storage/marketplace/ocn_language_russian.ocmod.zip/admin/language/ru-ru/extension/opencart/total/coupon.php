<?php
// Heading
$_['heading_title']    = 'Купон';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили общую сумму купона!';
$_['text_edit']        = 'Редактирование купона';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортировки';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав для изменения общей суммы купона!';