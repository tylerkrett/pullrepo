<?php
// Heading
$_['heading_title']    = 'Аккаунт';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили модуль учетной записи!';
$_['text_edit']        = 'Изменить модуль учетной записи';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав для изменения модуля учетной записи!';