<?php
// Heading
$_['heading_title']    = 'Магазин';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили модуль магазин!';
$_['text_edit']        = 'Редактирование модуля магазина';

// Entry
$_['entry_admin']      = 'Только для администраторов';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав для изменения модуля магазина!';