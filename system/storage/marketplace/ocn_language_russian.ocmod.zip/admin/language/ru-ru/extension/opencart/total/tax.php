<?php
// Heading
$_['heading_title']    = 'Налоги';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили общую сумму налогов!';
$_['text_edit']        = 'Редактирование общей суммы налога';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортировки';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение общей суммы налогов!';