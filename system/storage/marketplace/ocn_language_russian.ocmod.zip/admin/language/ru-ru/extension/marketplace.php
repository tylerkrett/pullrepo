<?php
// Heading
$_['heading_title']    = 'Маркетплейсы';

// Text
$_['text_success']     = 'Успех: Вы изменили торговые площадки!';
$_['text_list']        = 'Список торговых площадок';

// Column
$_['column_name']      = 'Название торговой площади';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение магазинов!';
$_['error_extension']  = 'Внимание: Расширение не существует!';