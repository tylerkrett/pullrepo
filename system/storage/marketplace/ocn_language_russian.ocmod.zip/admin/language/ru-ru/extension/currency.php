<?php
// Heading
$_['heading_title']    = 'Курсы валют';

// Text
$_['text_success']     = 'Успех: Вы изменили курсы валют!';
$_['text_list']        = 'Список курсов валют';

// Column
$_['column_name']      = 'Название курса валюты';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав для изменения курсов валют!';
$_['error_directory']  = 'Внимание: Каталог расширения не существует!';