<?php
// Heading
$_['heading_title']    = 'Информация';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили модуль информация!';
$_['text_edit']        = 'Редактирование модуля информации';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение модуля информации!';