<?php
// Heading
$_['heading_title']     = 'Доставка';

// Text
$_['text_success']      = 'Успех: Вы изменили доставку!';
$_['text_list']         = 'Список доставки';

// Column
$_['column_name']       = 'Способ доставки';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Порядок сортировки';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'Внимание: У вас нет прав для изменения доставки!';
$_['error_directory']   = 'Внимание: Каталог расширения не существует!';