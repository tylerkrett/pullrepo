<?php
// Heading
$_['heading_title']    = 'Всего';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили общую сумму всего!';
$_['text_edit']        = 'Редактирование общей суммы';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортировки';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав для изменения общей суммы всего!';