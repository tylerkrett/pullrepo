<?php
// Heading
$_['heading_title']    = 'Защита от ботов';

// Text
$_['text_success']     = 'Успех: Вы изменили капчи!';
$_['text_list']        = 'Список защит от ботов';

// Column
$_['column_name']      = 'Название капчи';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав для изменения капч!';
$_['error_directory']  = 'Внимание: Каталог расширения не существует!';