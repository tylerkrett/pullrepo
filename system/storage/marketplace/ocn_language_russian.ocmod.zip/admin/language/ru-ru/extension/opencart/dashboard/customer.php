<?php
// Heading
$_['heading_title']    = 'Всего покупателей';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили покупателя панели!';
$_['text_edit']        = 'Редактирование покупателя для панели';
$_['text_view']        = 'Подробнее...';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортировки';
$_['entry_width']      = 'Ширина';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав для изменения покупателя панели!';