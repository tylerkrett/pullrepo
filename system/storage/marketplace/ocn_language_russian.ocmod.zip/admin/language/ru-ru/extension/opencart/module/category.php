<?php
// Heading
$_['heading_title']    = 'Категория';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили модуль категории!';
$_['text_edit']        = 'Редактирование модуля категории';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение модуля категории!';