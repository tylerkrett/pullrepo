<?php
// Heading
$_['heading_title']    = 'Другие';

// Text
$_['text_success']     = 'Успешно: Вы изменили другое расширение!';
$_['text_list']        = 'Другой список';

// Column
$_['column_name']      = 'Другое имя';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение другого расширения!';
$_['error_directory']  = 'Внимание: Каталог расширения не существует!';