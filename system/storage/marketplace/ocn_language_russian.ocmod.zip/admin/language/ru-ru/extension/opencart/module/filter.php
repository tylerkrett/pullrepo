<?php
// Heading
$_['heading_title']    = 'Фильтр';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Вы изменили модуль фильтра!';
$_['text_edit']        = 'Редактирование модуля фильтра';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение модуля фильтр!';