<?php
// Heading
$_['heading_title']    = 'Аналитика';

// Text
$_['text_success']     = 'Успех: Вы изменили аналитику!';
$_['text_list']        = 'Список аналитики';

// Column
$_['column_name']      = 'Наименование аналитики';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав для изменения аналитики!';
$_['error_directory']  = 'Внимание: Каталог расширения не существует!';