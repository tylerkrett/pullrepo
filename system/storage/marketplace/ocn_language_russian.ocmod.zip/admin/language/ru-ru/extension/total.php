<?php
// Heading
$_['heading_title']     = 'Сумма заказа';

// Text
$_['text_success']      = 'Успех: Вы изменили всего!';

// Column
$_['column_name']       = 'Сумма заказа';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Порядок сортировки';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'Внимание: У вас нет прав для изменения общей суммы!';
$_['error_directory']   = 'Внимание: Каталог расширения не существует!';
