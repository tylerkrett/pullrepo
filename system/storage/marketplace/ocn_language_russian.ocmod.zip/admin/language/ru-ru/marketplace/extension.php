<?php
// Heading
$_['heading_title'] = 'Расширения';

// Text
$_['text_success']  = 'Успех: Вы изменили расширения!';
$_['text_list']     = 'Список расширений';
$_['text_type']     = 'Выберите тип расширения';
$_['text_filter']   = 'Фильтр';