<?php
// Heading
$_['heading_title']     = 'Автозагрузка';

// Text
$_['text_success']      = 'Успех: Вы изменили автозагрузку!';
$_['text_list']         = 'Список автозагрузки';

// Column
$_['column_code']       = 'Код запуска';
$_['column_sort_order'] = 'Порядок сортировки';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'Внимание: У вас нет прав для изменения автозагрузки!';
