<?php
// Text
$_['text_recommended'] = 'Рекомендуемые';
$_['text_install']     = 'Установить';
$_['text_uninstall']   = 'Деинсталляция';
$_['text_delete']      = 'Удалить';
