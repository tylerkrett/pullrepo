<?php
// Heading
$_['heading_title']    = 'Уведомления';

// Text
$_['text_success']     = 'Успех: Вы изменили уведомления!';
$_['text_list']        = 'Список уведомлений';

// Column
$_['column_message']   = 'Сообщение';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение уведомлений!';