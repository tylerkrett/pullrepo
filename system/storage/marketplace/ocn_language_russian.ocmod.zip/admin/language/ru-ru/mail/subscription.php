<?php
// Text
$_['text_subject']             = '%s - Подписка';
$_['text_subscription_id']     = 'Идентификатор подписки';
$_['text_date_added']          = 'Дата подписки:';
$_['text_subscription_status'] = 'Ваша подписка добавлена в следующий статус:';
$_['text_comment']             = 'Комментарии к вашей подписке:';
$_['text_payment_method']      = 'Метод оплаты';
$_['text_payment_code']        = 'Код оплаты';
$_['text_footer']              = 'Пожалуйста, ответьте на это письмо, если у вас есть какие-либо вопросы.';
