<?php
// Heading
$_['heading_title']         = 'OpenCart';

// Text
$_['text_notification']      = 'Уведомления';
$_['text_notification_all']  = 'Показать все';
$_['text_notification_none'] = 'Нет никаких уведомлений';
$_['text_profile']           = 'Ваш профиль';
$_['text_store']             = 'Магазины';
$_['text_help']              = 'Помощь';
$_['text_homepage']          = 'Домашняя страница OpenCart';
$_['text_support']           = 'Форум поддержки';
$_['text_documentation']     = 'Документация';
$_['text_logout']            = 'Выйти';