<?php
// Text
$_['text_footer']  = '<a href="https://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Все права защищены.<br/>Перевод <a href="https://forum.opencart.name" target="_blank">OpenCart.Name</a>';
$_['text_version'] = 'Версия %s';