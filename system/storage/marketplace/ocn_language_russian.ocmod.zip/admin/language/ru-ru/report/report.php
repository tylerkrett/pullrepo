<?php
// Heading
$_['heading_title'] = 'Отчеты';

// Text
$_['text_success']  = 'Успех: Вы изменили отчеты!';
$_['text_type']     = 'Выберите тип отчета';
$_['text_filter']   = 'Фильтр';
