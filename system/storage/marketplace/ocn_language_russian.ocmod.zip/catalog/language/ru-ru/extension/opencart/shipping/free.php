<?php
// Heading
$_['heading_title']    = 'Бесплатная доставка';

// Text
$_['text_description'] = 'Бесплатная доставка';