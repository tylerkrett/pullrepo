<?php
// Heading
$_['heading_title'] = 'Хиты продаж';