<?php
// Heading
$_['heading_title']     = 'Аккаунт';

// Text
$_['text_register']     = 'Регистрация';
$_['text_login']        = 'Войти';
$_['text_logout']       = 'Выйти';
$_['text_forgotten']    = 'Восстановить пароль';
$_['text_account']      = 'Моя учетная запись';
$_['text_edit']         = 'Изменить учетную запись';
$_['text_password']     = 'Пароль';
$_['text_address']      = 'Aдресная книга';
$_['text_wishlist']     = 'Список желаний';
$_['text_order']        = 'История заказа';
$_['text_download']     = 'Загрузки';
$_['text_reward']       = 'Бонусные баллы';
$_['text_return']       = 'Возвраты';
$_['text_transaction']  = 'Транзакции';
$_['text_newsletter']   = 'Рассылка';
$_['text_subscription'] = 'Подписки';