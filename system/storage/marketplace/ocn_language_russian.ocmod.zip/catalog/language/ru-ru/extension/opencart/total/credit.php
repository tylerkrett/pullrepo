<?php
// Text
$_['text_credit']   = 'Кредит магазина';
$_['text_order_id'] = 'Номер заказа: #%s';