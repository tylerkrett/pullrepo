<?php
// Heading
$_['heading_title']    = 'Фиксированная ставка';

// Text
$_['text_description'] = 'Фиксированная стоимость доставки';