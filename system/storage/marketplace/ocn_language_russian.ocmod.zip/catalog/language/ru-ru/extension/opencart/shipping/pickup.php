<?php
// Heading
$_['heading_title']    = 'Самовывоз';

// Text
$_['text_description'] = 'Самовывоз из магазина';