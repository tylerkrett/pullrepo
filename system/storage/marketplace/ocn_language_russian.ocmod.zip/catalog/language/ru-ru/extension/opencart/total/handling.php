<?php
// Text
$_['text_handling'] = 'Плата за обработку';