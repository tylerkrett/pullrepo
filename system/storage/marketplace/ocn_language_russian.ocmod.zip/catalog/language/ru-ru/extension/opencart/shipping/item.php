<?php
// Heading
$_['heading_title']    = 'За единицу';

// Text
$_['text_description'] = 'Стоимость доставки за единицу товара';