<?php
// Heading
$_['heading_title'] = 'Специальные предложения';