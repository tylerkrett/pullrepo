<?php
// Heading
$_['heading_title'] = 'Доставка на основе веса';

// Text
$_['text_weight']   = 'Вес:';