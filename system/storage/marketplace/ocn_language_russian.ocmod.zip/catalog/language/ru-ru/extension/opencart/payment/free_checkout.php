<?php
// Heading
$_['heading_title'] = 'Бесплатный заказ';