<?php
// Heading
$_['heading_title']        = 'Оплата при доставке';

// Error
$_['error_order_id']       = 'Идентификатор заказа отсутствует в сессии!';
$_['error_payment_method'] = 'Неправильный способ оплаты!';