<?php
// Text
$_['text_low_order_fee'] = 'Плата за низкую стоимость заказа';