<?php
// Text
$_['text_success']   = 'Успех: Ваш язык был изменен!';

// Error
$_['error_language'] = 'Внимание: Язык не найден!';