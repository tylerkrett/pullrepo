<?php
// Text
$_['text_success']   = 'Успех: Ваша валюта была изменена!';

// Error
$_['error_currency'] = 'Внимание: Валюта не найдена!';