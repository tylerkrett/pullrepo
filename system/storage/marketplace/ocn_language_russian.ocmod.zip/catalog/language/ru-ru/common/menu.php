<?php
// Text
$_['text_category']  = 'Категории';
$_['text_all']       = 'Показать все';
