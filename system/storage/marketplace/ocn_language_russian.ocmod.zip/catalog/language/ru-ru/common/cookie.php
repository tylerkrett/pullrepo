<?php
// Text
$_['text_success'] = 'Спасибо, что сообщили нам о вашем выборе!';
$_['text_cookie']  = 'Этот веб-сайт использует куки. Для получения дополнительной информации <a href="%s" class="alert-link modal-link">нажмите здесь</a>.';

// Button
$_['button_agree']    = 'Да, это прекрасно!';
$_['button_disagree'] = 'Нет, спасибо!';