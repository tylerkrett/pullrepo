<?php
// Text
$_['text_wishlist']      = 'Список желаний (%s)';
$_['text_shopping_cart'] = 'Корзина';
$_['text_account']       = 'Моя учетная запись';
$_['text_register']      = 'Регистрация';
$_['text_login']         = 'Войти';
$_['text_order']         = 'История заказа';
$_['text_transaction']   = 'Транзакции';
$_['text_download']      = 'Загрузки';
$_['text_logout']        = 'Выйти';
$_['text_checkout']      = 'Оформление заказа';