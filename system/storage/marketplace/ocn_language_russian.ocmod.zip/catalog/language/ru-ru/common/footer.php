<?php
// Text
$_['text_information']  = 'Информация';
$_['text_blog']         = 'Блог';
$_['text_service']      = 'Служба поддержки';
$_['text_extra']        = 'Дополнительно';
$_['text_contact']      = 'Связаться с нами';
$_['text_return']       = 'Возвраты';
$_['text_sitemap']      = 'Карта сайта';
$_['text_gdpr']         = 'GDPR';
$_['text_manufacturer'] = 'Бренды';
$_['text_voucher']      = 'Подарочные сертификаты';
$_['text_affiliate']    = 'Партнер';
$_['text_special']      = 'Специальные предложения';
$_['text_account']      = 'Моя учетная запись';
$_['text_order']        = 'История заказа';
$_['text_wishlist']     = 'Список желаний';
$_['text_newsletter']   = 'Рассылка';
$_['text_powered']      = 'Работает на <a href="https://www.opencart.com" target="_blank">OpenCart</a><br/> %s &copy; %s<br/>Перевод <a href="https://forum.opencart.name" target="_blank">OpenCart.Name</a>';
