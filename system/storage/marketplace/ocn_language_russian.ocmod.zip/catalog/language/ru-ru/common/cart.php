<?php
// Text
$_['text_items']                 = '%s товар(ов) - %s';
$_['text_points']                = 'Бонусные баллы';
$_['text_subscription']          = 'Подписка';
$_['text_subscription_trial']    = '%s каждые %d %s для %d платеж(а)(ей) тогда ';
$_['text_subscription_duration'] = '%s каждые %d %s для %d платеж(а)(ей)';
$_['text_subscription_cancel']   = '%s каждые %d %s до отмены';
$_['text_day']                   = 'день';
$_['text_week']                  = 'неделя';
$_['text_semi_month']            = 'полмесяца';
$_['text_month']                 = 'месяц';
$_['text_year']                  = 'год';
$_['text_no_results']            = 'Ваша корзина пуста!';
$_['text_cart']                  = 'Посмотреть корзину';
$_['text_checkout']              = 'Оформление заказа';

// Error
$_['error_product']              = 'Внимание: Товар не может быть найден!';