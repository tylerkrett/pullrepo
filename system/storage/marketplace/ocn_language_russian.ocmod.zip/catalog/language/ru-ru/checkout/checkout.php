<?php
// Heading
$_['heading_title'] = 'Оформление заказа';

// Text
$_['text_cart']     = 'Корзина';