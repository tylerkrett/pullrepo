<?php
// Text
$_['text_points']                = 'Бонусные баллы';
$_['text_subscription']          = 'Подписка';
$_['text_subscription_trial']    = '%s каждые %d %s для %d платеж(а)(ей) тогда ';
$_['text_subscription_duration'] = '%s каждые %d %s для %d платеж(а)(ей)';
$_['text_subscription_cancel']   = '%s каждые %d %s до отмены';
$_['text_day']                   = 'день';
$_['text_week']                  = 'неделя';
$_['text_semi_month']            = 'полмесяца';
$_['text_month']                 = 'месяц';
$_['text_year']                  = 'год';

// Column
$_['column_name']                = 'Название товара';
$_['column_model']               = 'Модель';
$_['column_quantity']            = 'Количество';
$_['column_price']               = 'Цена за единицу';
$_['column_total']               = 'Всего';