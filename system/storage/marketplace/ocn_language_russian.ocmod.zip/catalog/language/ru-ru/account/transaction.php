<?php
// Heading
$_['heading_title']      = 'Ваши транзакции';

// Column
$_['column_date_added']  = 'Дата добавления';
$_['column_description'] = 'Описание';
$_['column_amount']      = 'Сумма (%s)';

// Text
$_['text_account']       = 'Аккаунт';
$_['text_transaction']   = 'Ваши транзакции';
$_['text_total']         = 'Ваш текущий баланс:';
$_['text_no_results']    = 'У вас нет никаких транзакций!';