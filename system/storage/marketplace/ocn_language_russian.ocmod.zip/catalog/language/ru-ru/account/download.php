<?php
// Heading
$_['heading_title']     = 'Загрузки';

// Text
$_['text_account']      = 'Аккаунт';
$_['text_downloads']    = 'Загрузки';
$_['text_no_results']   = 'У вас не было заказов с файлами для скачивания!';

// Column
$_['column_order_id']   = 'Номер заказа';
$_['column_name']       = 'Название';
$_['column_size']       = 'Размер';
$_['column_date_added'] = 'Дата добавления';

// Error
$_['error_not_found']    = 'Ошибка: Не удалось найти файл %s!';
$_['error_headers_sent'] = 'Ошибка: Заголовки уже отправлен!';
