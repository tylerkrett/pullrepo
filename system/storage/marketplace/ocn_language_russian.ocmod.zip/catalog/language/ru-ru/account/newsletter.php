<?php
// Heading
$_['heading_title']    = 'Подписка на рассылку';

// Text
$_['text_account']     = 'Аккаунт';
$_['text_newsletter']  = 'Рассылка';
$_['text_success']     = 'Успех: Ваша подписка на рассылку была успешно обновлена!';

// Entry
$_['entry_newsletter'] = 'Подписаться';