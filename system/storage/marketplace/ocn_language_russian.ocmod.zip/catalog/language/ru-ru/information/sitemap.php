<?php
// Heading
$_['heading_title']    = 'Карта сайта';

// Text
$_['text_special']     = 'Специальные предложения';
$_['text_account']     = 'Моя учетная запись';
$_['text_edit']        = 'Информация об учетной записи';
$_['text_password']    = 'Пароль';
$_['text_address']     = 'Aдресная книга';
$_['text_history']     = 'История заказа';
$_['text_download']    = 'Загрузки';
$_['text_cart']        = 'Корзина';
$_['text_checkout']    = 'Оформление заказа';
$_['text_search']      = 'Искать';
$_['text_information'] = 'Информация';
$_['text_contact']     = 'Связаться с нами';