<?php
// Text
$_['text_subject']              = '%s - Заказ %s - Отменена Подписка';
$_['text_received']             = 'Вы получили отмену подписки.';
$_['text_orders_id']            = 'Номер заказа:';
$_['text_subscription_id']      = 'Идентификатор подписки';
$_['text_date_added']           = 'Дата добавления:';
$_['text_subscription_status']  = 'Статус подписки:';
$_['text_comment']              = 'Комментарии к вашей подписке:';
$_['text_canceled']             = 'Успех: Профиль подписки был отменен!';
