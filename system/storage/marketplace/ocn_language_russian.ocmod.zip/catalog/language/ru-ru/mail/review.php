<?php
// Text
$_['text_subject']  = '%s - Отзыв о товаре';
$_['text_waiting']  = 'Вас ждет новый обзор товара.';
$_['text_product']  = 'Товар:';
$_['text_reviewer'] = 'Рецензент:';
$_['text_rating']   = 'Рейтинг:';
$_['text_review']   = 'Текст отзыва:';