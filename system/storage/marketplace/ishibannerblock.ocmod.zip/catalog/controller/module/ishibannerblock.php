<?php
namespace Opencart\Catalog\Controller\Extension\ishibannerblock\Module;
use \Opencart\System\Helper AS Helper;
class IshiBannerBlock extends \Opencart\System\Engine\Controller {
	public function index(array $setting): string {
		
		static $module = 0;
		$this->load->model('tool/image');
		
		$language_id = $this->config->get('config_language_id');
		$data['title'] = (isset($setting['title'][$language_id])) ? $setting['title'][$language_id] : '' ;
		$data['banners'] = array();

		$banners = $setting['ishibanner'];
		
		$data['style'] = $setting['style'];
		$data['column'] = $setting['column'];
		$column = $setting['column'];
		$data['ishi_randomnumer'] = "ishibannerblock-" . rand();
		$data['scale'] = (isset($setting['scale']) && $setting['scale'] == 1) ? 'scale' : '';
		
		if($column == 1){
			$data['column_class'] = 'col-md-12 col-sm-12 col-xs-12';
		}elseif($column == 2){
			$data['column_class'] = 'col-lg-6 col-md-12 col-sm-12 col-xs-12';
		}elseif($column == 3){
			$data['column_class'] = 'col-lg-4 col-md-8 col-sm-8 col-xs-12';
		}elseif($column == 4){
			$data['column_class'] = 'col-xl-3 col-lg-6 col-md-6 col-sm-12 col-xs-12';
		}
		

		$lang = $this->config->get('config_language_id');
		
		if(!empty($banners)){
			
			$bannercount = count($banners);
			if($bannercount == 1){
				$data['bannerclass'] = 'one_bannerblock';
			}elseif($bannercount == 2){
				$data['bannerclass'] = 'two_bannerblock';
			}elseif($bannercount == 3){
				$data['bannerclass'] = 'three_bannerblock';
			}elseif($bannercount == 4){
				$data['bannerclass'] = 'four_bannerblock';
			}else {
				$data['bannerclass'] = 'gallery_block';
			}

			foreach ($banners as $banner) {
				if (is_file(DIR_IMAGE . $banner['image'])) {
					$showtext = (isset($banner['showtext']) && $banner['showtext'] == 1) ? '1' : '0';
					$titlecolor = isset($banner['titlecolor']) ? $banner['titlecolor']: '';
					$subtitlecolor = isset($banner['subtitlecolor']) ? $banner['subtitlecolor']: '';
					$desccolor = isset($banner['desccolor']) ? $banner['desccolor']: '';
					$descbgcolor = isset($banner['descbgcolor']) ? $banner['descbgcolor']: '';
					$data['banners'][] = array(
						'title' => $banner['title'][$lang],
						'subtitle' => $banner['subtitle'][$lang],
						'titlecolor' => $titlecolor,
						'subtitlecolor' => $subtitlecolor,
						'alignment' => $banner['alignment'],
						'position' => $banner['position'],
						'showtext' => $showtext,
						'button_name' => $banner['button_name'][$lang],
						'link'  => $banner['link'],
						'image' => $this->model_tool_image->resize($banner['image'], $setting['width'], $setting['height'])
					);
				}
			}
		}

		$data['module'] = $module++;

		return $this->load->view('extension/ishibannerblock/module/ishibannerblock', $data);
	}
}