<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_price'] = 'السعر:';
$_['text_tax']   = 'السعر بدون ضريبة :';
