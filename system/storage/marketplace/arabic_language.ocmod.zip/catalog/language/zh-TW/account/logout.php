<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'خروج';

// Text
$_['text_message']  = '<p>تم تسجيل خروجك من الحساب. يمكنك مغادرة الموقع بأمان</p><p>سلة التسوق الخاصة بك قد تم حفظها، الطلبات الموجودة في السلة سوف يتم استعادتها كلما قمت بتسجيل الدخول إلى حسابك.</p>';
$_['text_account']  = 'الحساب';
$_['text_logout']   = 'خروج';