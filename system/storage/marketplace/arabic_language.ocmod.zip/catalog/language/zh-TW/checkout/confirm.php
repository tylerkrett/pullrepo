<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subscription']          = 'خطة الاشتراك';
$_['text_subscription_trial']    = '%s كل %d %s من %d دفعة ثم ';
$_['text_subscription_duration'] = '%s كل %d %s من %d دفعة';
$_['text_subscription_cancel']   = '%s كل %d %s حتى الالغاء';
$_['text_day']                   = 'يوم';
$_['text_week']                  = 'اسبوع';
$_['text_semi_month']            = 'نصف شهري';
$_['text_month']                 = 'شهر';
$_['text_year']                  = 'سنة';

// Column
$_['column_name']                = 'اسم المنتج';
$_['column_model']               = 'النوع';
$_['column_quantity']            = 'الكمية';
$_['column_price']               = 'سعر الوحدة';
$_['column_total']               = 'الاجمالي';
