<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']         = 'تم تعديل بيانات العميل بنجاح';

// Error
$_['error_customer']       = 'تحذير: تعذر العثور على العميل !';
$_['error_customer_group'] = 'لا يبدو أن مجموعة العملاء صالحة !';
$_['error_firstname']      = 'الاسم الاول يجب ان يكون بين 1 و 32 حرف !';
$_['error_lastname']       = 'الاسم الاخير يجب ان يكون بين 1 و 32 حرف !';
$_['error_email']          = 'يبدو أن عنوان البريد الإلكتروني غير صالح !';
$_['error_telephone']      = 'الرقم يجب ان يكون بين 3 و 32 رقم !';
$_['error_custom_field']   = '%s مطلوب!';
$_['error_regex']          = '%s ليس إدخالاً صالحًا!';
