<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']           = 'نجاح: تم تحديد طريقة الشحن!';

// Error
$_['error_shipping_address'] = 'تحذير: عنوان الشحن مطلوب !';
$_['error_shipping_method']  = 'تحذير: طريقة الشحن مطلوبة !';
$_['error_no_shipping']      = 'تحذير: لا توجد خيارات شحن متاحة !';
$_['error_shipping']         = 'تحذير: لا توجد منتجات تتطلب الشحن';
