<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']      = '%s - تحديث الطلب %s';
$_['text_order_id']     = 'رقم الطلب:';
$_['text_date_added']   = 'تاريخ الطلب:';
$_['text_order_status'] = 'لقد تم تحديث حالة طلبك إلى :';
$_['text_comment']      = 'الملاحظات على طلبك هي :';
$_['text_link']         = 'لاستعراض تفاصيل الطلب اضغط على الرابط التالي :';
$_['text_footer']       = 'الرجاء الرد على هذا البريد الالكتروني في حالة وجود استفسارات.';
