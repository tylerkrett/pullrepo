<?php
// Heading
$_['heading_title'] = 'Use Gift Certificate';

// Text
$_['text_voucher']  = 'Gift Certificate (%s)';
$_['text_success']  = 'Success: Your gift certificate discount has been applied!';
$_['text_remove']   = 'Success: Your gift certificate discount has been removed!';

// Entry
$_['entry_voucher'] = 'Enter your gift certificate code here';

// Error
$_['error_voucher'] = 'Warning: Gift Certificate is either invalid or the balance has been used up!';
$_['error_status']  = 'Warning: Gift Certificate are not enabled on this store!';