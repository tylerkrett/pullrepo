<?php

$_['text_information']  = 'INFORMATION';
$_['text_contact']      = 'Contact Us';
$_['text_email']      = 'Email';
$_['text_address']      = 'Address';