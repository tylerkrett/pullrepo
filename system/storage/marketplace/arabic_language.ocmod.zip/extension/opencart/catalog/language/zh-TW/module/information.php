<?php
// Heading
$_['heading_title'] = 'Information';

// Text
$_['text_contact']  = 'Contact Us';
$_['text_sitemap']  = 'Site Map';
$_['text_aboutus']  = 'About Us';
$_['text_FAQ']  = 'FAQ';