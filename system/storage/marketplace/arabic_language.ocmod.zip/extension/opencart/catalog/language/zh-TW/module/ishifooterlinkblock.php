<?php

$_['text_information']  = 'INFORMATION';
$_['text_contact']      = 'Contact Us';
$_['text_email']      = 'Email';
$_['text_address']      = 'Address';
$_['text_service']      = 'CUSTOMER SERVICES';
$_['text_extra']        = 'EXTRAS';
$_['text_contact']      = 'Contact Us';
$_['text_email']      = 'Email';
$_['text_address']      = 'Address';
$_['text_return']       = 'Returns';
$_['text_sitemap']      = 'Site Map';
$_['text_gdpr']         = 'GDPR';
$_['text_manufacturer'] = 'Brands';
$_['text_voucher']      = 'Gift Certificates';
$_['text_affiliate']    = 'Affiliate';
$_['text_special']      = 'Specials';
$_['text_account']      = 'My Account';
$_['text_order']        = 'Order History';
$_['text_wishlist']     = 'Wish List';
$_['text_newsletter']   = 'Newsletter';