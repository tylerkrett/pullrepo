<?php
//  Website: yasmalik.com
//  E-Mail : info@yasmalik.com

// Heading
$_['heading_title']    = 'القائمة الرئيسية';

// Text
$_['text_success']     = 'تم التعديل !';
$_['text_list']        = 'قائمة';

// Column
$_['column_name']      = 'اسم القائمة';
$_['column_status']    = 'الحالة';
$_['column_action']    = 'تحرير';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
