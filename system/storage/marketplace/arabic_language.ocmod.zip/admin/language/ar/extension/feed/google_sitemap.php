<?php
//  Website: yasmalik.com
//  E-Mail : info@yasmalik.com

// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_extension']         = 'الموديولات';
$_['text_success']     = 'تم التعديل !';
$_['text_list']        = 'قائمة';
$_['text_edit']        = 'تحرير';

// Entry
$_['entry_status']     = 'الحالة :';
$_['entry_data_feed']  = 'رابط الخلاصة :';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
