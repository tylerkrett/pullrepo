<?php
// Heading
$_['heading_title']    = 'Notifications';

// Text
$_['text_success']     = 'Success: You have modified notifications!';
$_['text_list']        = 'Notification List';

// Column
$_['column_message']   = 'Message';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify notifications!';