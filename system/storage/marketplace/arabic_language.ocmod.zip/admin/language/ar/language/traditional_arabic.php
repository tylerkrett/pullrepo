<?php
// Heading
$_['heading_title']    = 'Arabic';

// Text
$_['text_extension']   = 'Extension module';
$_['text_success']     = 'Success: Arabic has been updated!';
$_['text_edit']        = 'Edit Arabic';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to edit Arabic!';
