<?php
// Heading
$_['heading_title']	       = '<img src="view/image/ishi-icon.png"> <b>Ishi FAQ Block</b>';

$_['heading_title1']    = 'Ishi FAQ Block';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Ishi FAQ Block module!';
$_['text_edit']        = 'Edit Ishi FAQ Block Module';

// Entry
$_['entry_name']       = 'Module Name';
$_['entry_banner']     = 'Testimonial';
$_['entry_addbanner']     = 'Add Testimonial';
$_['entry_status']     = 'Status';
$_['tab_general']      = 'General';
$_['entry_description'] = 'Description';
$_['entry_username']    = 'User Name';


// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Ishi Banner Block module!';
$_['error_name']       = 'Module Name must be between 3 and 64 characters!';
$_['error_title']      = 'Module Title must be between 2 and 64 characters!';
$_['error_imgtitle']   = 'Image Title must be between 3 and 64 characters!';
$_['error_button_name']= 'Button Title must be between 3 and 64 characters!';
$_['error_width']      = 'Width required!';
$_['error_height']     = 'Height required!';